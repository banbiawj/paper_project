from typing import Union,Generic, TypeVar
import uvicorn
import os
import json
from typing import List
from fastapi import FastAPI,APIRouter, File, UploadFile, HTTPException,Path, Request ,Form
from pydantic import BaseModel , Field
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse,JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from mylib.File import JsonOperate
from enum import Enum

IDIOM_PATH ="static/data/idiom"
WORDS_PATH ="static/data/words"


router =  APIRouter()
ROOTPATH = os.getcwd()

T = TypeVar("T")

class REST_API_standard(BaseModel, Generic[T]):
    code: int
    message: str
    data: T  # T 就是泛型参数

class ErrorResponse(BaseModel):
    code: int
    message: str



class TextResponse(BaseModel):
    error: str
    criterion: str
    position: str

class limit(str,Enum):
    idiom="idiom"
    words="words"


class CreateFavoriteRequest(BaseModel):
    TypeName:limit = Field(default=limit.idiom)
    FavoriteName:str = Field()



class ReadDataRequest(BaseModel):
    TypeName:limit = Field(default=limit.idiom)
    FavoriteName:str = Field()

# 创建收藏夹
@router.post("/CreateType", response_model=REST_API_standard)
async def CreateType(request: CreateFavoriteRequest):
    try:
        # 从 request 里拿到前端传来的数据
        typename = request.TypeName
        favoritename = request.FavoriteName
        if typename =="idiom":
            create_path =IDIOM_PATH
        elif typename =="words":
            create_path =WORDS_PATH
        JsonPath = JsonOperate.create_json_file(create_path,favoritename)
        result = REST_API_standard(
            code=200,
            message=("succeed"),
            data = JsonPath
        )
        return result
    except Exception as e:
        error = ErrorResponse(code=500, message=f"analyse failed: {e}")
        return JSONResponse(
            status_code=500,       # <-- HTTP 状态码
            content=error.model_dump()   # <-- 用 BaseModel 转 dict
        )
    
class SaveDataRequest(BaseModel):
    TypeName:limit = Field(default=limit.idiom)
    FavoriteName:str = "default"
    message: T

# 保存数据
@router.post("/SaveData", response_model=REST_API_standard)
async def SaveData(request: SaveDataRequest):
    try:
        # 从 request 里拿到前端传来的数据
        typename = request.TypeName
        favoritename = request.FavoriteName
        jsoncontent = request.message

        if typename =="idiom":
            Save_path = IDIOM_PATH
        elif typename =="words":
            Save_path = WORDS_PATH
        query_list = JsonOperate.read_json_file(Save_path,"query")
        favorite_list = JsonOperate.read_json_file(Save_path,favoritename)
        query = jsoncontent['word']
        query_result =JsonOperate.find_in_json(query_list,'word',query)
        favorite_result =JsonOperate.find_in_json(favorite_list,'word',query)

        print(f"成语查询：{query_result}")
        print(f"成语查询：{favorite_result}")
        if query_result and favorite_result:
            result = REST_API_standard(
            code=200,
            message=("already exist!"),
            data = query_result
            )
        else:
            if favoritename =='query.json' or favoritename =='query':
                favoritename ='default.json' 
            jsoncontent['favoritename'] = favoritename
            jsoncontent['type'] = typename
            JsonPath = JsonOperate.append_json_to_file(Save_path,favoritename,jsoncontent)
            if not query_result:
                JsonOperate.append_json_to_file(Save_path,"query",jsoncontent)
            result = REST_API_standard(
            code=200,
            message=("Save succeed!"),
            data = JsonPath
            )

        return result
    except Exception as e:
        error = ErrorResponse(code=500, message=f"analyse failed: {e}")
        return JSONResponse(
            status_code=500,       # <-- HTTP 状态码
            content=error.model_dump()   # <-- 用 BaseModel 转 dict
        )

# 获取所有内容
@router.post("/ReadData", response_model=REST_API_standard)
async def ReadData(request: ReadDataRequest):
    try:
        # 从 request 里拿到前端传来的数据
        typename = request.TypeName
        favoritename = request.FavoriteName

        if typename =="idiom":
            create_path =IDIOM_PATH
        elif typename =="words":
            create_path =WORDS_PATH
        
        JsonContent = JsonOperate.read_json_file(create_path,favoritename)
        result = REST_API_standard(
            code=200,
            message=("succeed"),
            data = JsonContent
        )
        return result
    except Exception as e:
        error = ErrorResponse(code=500, message=f"analyse failed: {e}")
        return JSONResponse(
            status_code=500,       # <-- HTTP 状态码
            content=error.model_dump()   # <-- 用 BaseModel 转 dict
        )


#删除
class DeleteDataRequest(BaseModel):
    TypeName:limit = Field(default=limit.idiom)
    FavoriteName:str = "default"
    message: T

@router.post("/DeleteData", response_model=REST_API_standard)
async def DeleteData(request: DeleteDataRequest):
    try:
        # 从 request 里拿到前端传来的数据
        typename = request.TypeName
        favoritename = request.FavoriteName
        jsoncontent = request.message

        if typename =="idiom":
            delete_path =IDIOM_PATH
        elif typename =="words":
            delete_path =WORDS_PATH
        
        remove_end = JsonOperate.remove_save_json(delete_path,favoritename,jsoncontent)

        JsonContent = JsonOperate.read_json_file(delete_path,favoritename)
        if remove_end==False:
            result = REST_API_standard(
                code=200,
                message=("delete succeed!"),
                data = JsonContent
            )
        else:
            result = REST_API_standard(
                code=400,
                message=("delete succeed!"),
                data = remove_end
            )
        
        return result
    except Exception as e:
        error = ErrorResponse(code=500, message=f"analyse failed: {e}")
        return JSONResponse(
            status_code=500,       # <-- HTTP 状态码
            content=error.model_dump()   # <-- 用 BaseModel 转 dict
        )


#修改
class AlterDataRequest(BaseModel):
    TypeName:limit = Field(default=limit.idiom)
    FavoriteName:str = "default"
    message: T

@router.post("/alterData", response_model=REST_API_standard)
async def alterData(request: AlterDataRequest):
    try:
        # 从 request 里拿到前端传来的数据
        typename = request.TypeName
        favoritename = request.FavoriteName
        jsoncontent = request.message

        if typename =="idiom":
            delete_path =IDIOM_PATH
        elif typename =="words":
            delete_path =WORDS_PATH
        
        replace_end = JsonOperate.replace_save_json(delete_path,favoritename,jsoncontent)

        if replace_end==False:
            result = REST_API_standard(
                code=200,
                message=("alter succeed!"),
                data = None
            )
        else:
            result = REST_API_standard(
                code=400,
                message=("alter succeed!"),
                data = replace_end
            )
        
        return result
    except Exception as e:
        error = ErrorResponse(code=500, message=f"analyse failed: {e}")
        return JSONResponse(
            status_code=500,       # <-- HTTP 状态码
            content=error.model_dump()   # <-- 用 BaseModel 转 dict
        )



